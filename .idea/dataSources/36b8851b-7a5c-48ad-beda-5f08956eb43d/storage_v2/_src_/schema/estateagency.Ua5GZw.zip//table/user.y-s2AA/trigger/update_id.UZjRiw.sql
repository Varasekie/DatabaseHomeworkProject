create definer = root@localhost trigger update_id
    after update
    on user
    for each row
begin
    select ID from user where No = old.No into @newID;
    insert into recordId (No, oldID, newID, Time)
    values (OLD.No, OLD.ID, @newID, NOW());
end;

