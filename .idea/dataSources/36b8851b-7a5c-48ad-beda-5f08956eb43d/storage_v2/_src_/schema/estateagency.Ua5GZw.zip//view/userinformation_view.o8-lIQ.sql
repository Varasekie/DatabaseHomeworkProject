create view userinformation_view as
select `estateagency`.`user`.`Name`         AS `Name`,
       `estateagency`.`password`.`Password` AS `password`,
       `estateagency`.`user`.`ID`           AS `ID`,
       `estateagency`.`user`.`Tele`         AS `tele`,
       `estateagency`.`user`.`Sex`          AS `Sex`
from (`estateagency`.`password`
         join `estateagency`.`user` on ((`estateagency`.`user`.`No` = `estateagency`.`password`.`ID`)));

