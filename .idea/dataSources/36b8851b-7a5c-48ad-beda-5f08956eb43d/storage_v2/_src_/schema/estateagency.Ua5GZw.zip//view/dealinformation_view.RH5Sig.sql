create definer = root@localhost view dealinformation_view as
select `estateagency`.`deal`.`HouseNo`                           AS `HouseNo`,
       `estateagency`.`house`.`Location`                         AS `Location`,
       `estateagency`.`employer`.`Tele`                          AS `Tele`,
       `estateagency`.`user`.`Tele`                              AS `Tele`,
       `estateagency`.`deal`.`Time`                              AS `Time`,
       `estateagency`.`deal`.`Price`                             AS `Price`,
       `estateagency`.`deal`.`Contract`                          AS `Contract`,
       `estateagency`.`employer`.`Name`                          AS `Name`,
       `estateagency`.`deal`.`EmployerId`                        AS `EmployerId`,
       `estateagency`.`user`.`No`                                AS `No`,
       `estateagency`.`user`.`Name`                              AS `Name`,
       `estateagency`.`user`.`ID`                                AS `ID`,
       (select `estateagency`.`user`.`ID`
        from (`estateagency`.`user`
                 join `estateagency`.`house` `h` on ((`estateagency`.`user`.`No` = `h`.`OwnerId`)))
        where (`h`.`HouseNo` = `estateagency`.`deal`.`HouseNo`)) AS `Name_exp_13`,
       (select `estateagency`.`user`.`No`
        from (`estateagency`.`user`
                 join `estateagency`.`house` `h` on ((`estateagency`.`user`.`No` = `h`.`OwnerId`)))
        where (`h`.`HouseNo` = `estateagency`.`deal`.`HouseNo`)) AS `Name_exp_14`
from `estateagency`.`deal`
         join `estateagency`.`employer`
         join `estateagency`.`user`
         join `estateagency`.`house`
where ((`estateagency`.`deal`.`EmployerId` = `estateagency`.`employer`.`EmployerId`) and
       (`estateagency`.`deal`.`No` = `estateagency`.`user`.`No`) and
       (`estateagency`.`deal`.`HouseNo` = `estateagency`.`house`.`HouseNo`));

