create
    definer = root@localhost procedure inspect_proc(IN Houseid char(6), IN EmployerNo char(4), IN buyerNo char(6),
                                                    IN times datetime, OUT message varchar(50))
begin
    if ((select count(*)
         from inspection
         where HouseNo = Houseid
           and EmployerId = EmployerNo
           and No = buyerNo
           and Time = times) != 0)
    then
        select message = '已预约过';
    end if;
    if ((select count(*)
         from inspection
         where HouseNo = Houseid
           and EmployerId = EmployerNo
           and No = buyerNo
           and Time = times) = 0)
    then
        insert inspection (HouseNo, EmployerId, No, Time) values (Houseid, EmployerNo, buyerNo, times);
        select message = '成功添加';
    end if;
    select message;
end;

