create definer = root@localhost trigger update_deal
    after insert
    on deal
    for each row
begin
    update house
    set Conditions = '使用中'
    where HouseNo = NEW.HouseNo;
    update houseexpect
    set Conditions = '已处理'
    where UserId = NEW.No;
end;

