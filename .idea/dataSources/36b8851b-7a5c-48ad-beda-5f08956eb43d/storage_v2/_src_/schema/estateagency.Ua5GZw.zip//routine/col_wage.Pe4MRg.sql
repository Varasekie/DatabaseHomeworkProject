create
    definer = root@localhost procedure col_wage(IN time datetime, IN commission int, IN No char(6), OUT wages int)
begin

    declare wage int ;
    set wages = (select count(*) from deal where Time like time and EmployerId = No)*commission;
    select wages;
end;

