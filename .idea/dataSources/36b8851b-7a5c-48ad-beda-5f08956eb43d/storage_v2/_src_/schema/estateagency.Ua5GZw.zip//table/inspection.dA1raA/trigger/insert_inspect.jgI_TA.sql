create definer = root@localhost trigger insert_inspect
    after insert
    on inspection
    for each row
begin
    update houseexpect set Conditions = '已处理' where houseexpect.UserId= NEW.No;
end;

