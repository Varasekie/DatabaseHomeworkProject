create
    definer = root@localhost procedure changeCondition(IN houseID char(6), OUT message char(10), IN userNo char(6))
begin
    update houseexpect set Conditions = '已成交' where UserId = UserNo and Conditions = '待见面';
    update house set Conditions = '使用中' where HouseNo = houseID;
    select message = '已同时成功修改';
end;

