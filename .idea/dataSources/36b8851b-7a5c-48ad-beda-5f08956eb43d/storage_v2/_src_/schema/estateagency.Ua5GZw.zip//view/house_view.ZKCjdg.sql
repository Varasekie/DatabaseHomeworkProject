create definer = root@localhost view house_view as
select `estateagency`.`house`.`HouseNo`    AS `HouseNo`,
       `estateagency`.`house`.`Area`       AS `Area`,
       `estateagency`.`house`.`Location`   AS `Location`,
       `estateagency`.`house`.`Type`       AS `Type`,
       `estateagency`.`house`.`Price`      AS `Price`,
       `u`.`No`                            AS `No`,
       `u`.`Tele`                          AS `tele`,
       `u`.`Name`                          AS `Name`,
       `estateagency`.`house`.`Conditions` AS `Conditions`
from (`estateagency`.`house`
         join `estateagency`.`user` `u` on ((`u`.`No` = `estateagency`.`house`.`OwnerId`)));

