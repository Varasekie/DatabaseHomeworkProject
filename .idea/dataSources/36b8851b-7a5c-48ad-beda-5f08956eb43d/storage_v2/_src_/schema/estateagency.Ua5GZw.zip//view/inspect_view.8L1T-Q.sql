create definer = root@localhost view inspect_view as
select `estateagency`.`user`.`No`               AS `No`,
       `estateagency`.`user`.`Name`             AS `Name`,
       `estateagency`.`inspection`.`Time`       AS `Time`,
       `estateagency`.`employer`.`EmployerId`   AS `EmployerId`,
       `estateagency`.`employer`.`Name`         AS `Name`,
       `estateagency`.`employer`.`Tele`         AS `Tele`,
       `estateagency`.`user`.`Tele`             AS `Tele`,
       `estateagency`.`house`.`HouseNo`         AS `HouseNo`,
       `estateagency`.`house`.`Location`        AS `Location`,
       `estateagency`.`house`.`Area`            AS `Area`,
       `estateagency`.`house`.`Price`           AS `Price`,
       `estateagency`.`inspection`.`condiotion` AS `condiotion`
from `estateagency`.`employer`
         join `estateagency`.`inspection`
         join `estateagency`.`house`
         join `estateagency`.`user`
where ((`estateagency`.`inspection`.`EmployerId` = `estateagency`.`employer`.`EmployerId`) and
       (`estateagency`.`inspection`.`HouseNo` = `estateagency`.`house`.`HouseNo`) and
       (`estateagency`.`user`.`No` = `estateagency`.`inspection`.`No`));

