create definer = root@localhost view inspect_view as
select `estateagency`.`user`.`Name`           AS `Name`,
       `estateagency`.`house`.`Location`      AS `Location`,
       `estateagency`.`inspection`.`Time`     AS `time`,
       `estateagency`.`employer`.`Name`       AS `Name`,
       `estateagency`.`user`.`Tele`           AS `Tele`,
       `estateagency`.`employer`.`Tele`       AS `Tele`,
       `estateagency`.`inspection`.`UserNo`   AS `UserNo`,
       `estateagency`.`employer`.`EmployerId` AS `EmployerId`
from `estateagency`.`inspection`
         join `estateagency`.`user`
         join `estateagency`.`employer`
         join `estateagency`.`house`
where ((`estateagency`.`inspection`.`UserNo` = `estateagency`.`user`.`No`) and
       (`estateagency`.`inspection`.`EmployerId` = `estateagency`.`employer`.`EmployerId`) and
       (`estateagency`.`inspection`.`HouseNo` = `estateagency`.`house`.`HouseNo`));

