create definer = root@localhost trigger person_del
    after delete
    on person
    for each row
BEGIN
        delete from pay
            where pay.No = OLD.No;
    end;

