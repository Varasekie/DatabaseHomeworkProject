create definer = root@localhost view view_pay as
select `education0301`.`pay`.`Year`         AS `Year`,
       `education0301`.`pay`.`Month`        AS `Month`,
       `education0301`.`person`.`No`        AS `NO`,
       `education0301`.`person`.`Name`      AS `Name`,
       `education0301`.`person`.`Sex`       AS `Sex`,
       `education0301`.`person`.`Professor` AS `Professor`,
       `education0301`.`dept`.`DeptName`    AS `DeptName`,
       `education0301`.`pay`.`Base`         AS `Base`,
       `education0301`.`pay`.`Bonus`        AS `Bonus`,
       `education0301`.`pay`.`Deduct`       AS `Deduct`,
       `education0301`.`pay`.`Fact`         AS `Fact`
from `education0301`.`person`
         join `education0301`.`pay`
         join `education0301`.`dept`
where ((`education0301`.`person`.`No` = `education0301`.`pay`.`No`) and
       (`education0301`.`person`.`DeptNo` = `education0301`.`dept`.`DeptNo`));

