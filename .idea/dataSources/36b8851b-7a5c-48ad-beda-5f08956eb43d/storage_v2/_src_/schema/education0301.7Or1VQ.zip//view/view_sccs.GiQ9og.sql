create definer = root@localhost view view_sccs as
select `education0301`.`student`.`Sno`            AS `Sno`,
       `c`.`Cname`                                AS `Cname`,
       `c`.`Ccredit`                              AS `Ccredit`,
       `education0301`.`sc`.`Grade`               AS `Grade`,
       ((`education0301`.`sc`.`Grade` - 50) / 10) AS `(Grade - 50) / 10`
from ((`education0301`.`student` left join `education0301`.`sc` on ((`education0301`.`student`.`Sno` = `education0301`.`sc`.`Sno`)))
         join `education0301`.`course` `c` on ((`education0301`.`sc`.`Cno` = `c`.`Cno`)))
where (`education0301`.`student`.`Sdept` = 'CS');

