create definer = root@localhost view view_persondp as
select `education0301`.`person`.`No`        AS `No`,
       `education0301`.`person`.`Name`      AS `Name`,
       `education0301`.`person`.`Sex`       AS `Sex`,
       `education0301`.`person`.`Birthday`  AS `Birthday`,
       `education0301`.`person`.`Professor` AS `Professor`,
       `d`.`DeptName`                       AS `DeptName`
from (`education0301`.`person`
         join `education0301`.`dept` `d` on ((`d`.`DeptNo` = `education0301`.`person`.`DeptNo`)));

