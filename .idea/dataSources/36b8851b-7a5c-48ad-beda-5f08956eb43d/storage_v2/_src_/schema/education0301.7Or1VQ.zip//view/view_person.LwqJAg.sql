create definer = root@localhost view view_person as
select `education0301`.`person`.`No`        AS `No`,
       `education0301`.`person`.`Name`      AS `Name`,
       `education0301`.`person`.`Sex`       AS `Sex`,
       `education0301`.`person`.`Professor` AS `Professor`,
       `education0301`.`person`.`DeptNo`    AS `DeptNo`
from `education0301`.`person`;

